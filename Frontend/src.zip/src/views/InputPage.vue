<template>
    <div>
        <h1>输入界面</h1>
        <input type="text" v-model="inputText" placeholder="输入标题" />
        <button @click="goToOutputPage">切换到输出界面</button>
    </div>
</template>
  
<script>
export default {
    data() {
        return {
            inputText: '',
        };
    },
    methods: {
        goToOutputPage() {
            // 通过 $router.push() 方法改变路由，传递参数
            this.$router.push({
                name: 'output',
                query: {
                    title: this.inputText,
                    username: "hh"
                },
            });
        },
    },
};
</script>
  