<template>
    <div>
        <h1>{{ $route.query.title }}</h1>
        <h2>{{ $route.query.username }}</h2>
        <button @click="goToInputPage">切换到输入界面</button>
    </div>
</template>
  
<script>
export default {
    methods: {
        goToInputPage() {
            // 使用 $router.push() 方法返回到输入页面
            this.$router.push({
                name: 'input',
            });
        },
    },
};
</script>
  